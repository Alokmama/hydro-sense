// Data siswa disimpan di sini
let dataSiswa = [];

// Element DOM
const formNilai = document.getElementById('formNilai');
const namaInput = document.getElementById('nama');
const utsInput = document.getElementById('uts');
const pasInput = document.getElementById('pas');
const tbody = document.getElementById('tbody');
const noData = document.getElementById('noData');
const tabelNilai = document.getElementById('tabelNilai');

// Element Statistik
const totalSiswaEl = document.getElementById('totalSiswa');
const siswaLulusEl = document.getElementById('siswaLulus');
const siswaTidakLulusEl = document.getElementById('siswaTidakLulus');
const rataRataKelasEl = document.getElementById('rataRataKelas');

// Event listener untuk form
formNilai.addEventListener('submit', function(e) {
    e.preventDefault();
    tambahDataSiswa();
});

// Fungsi untuk menghitung rata-rata
function hitungRataRata(uts, pas) {
    return ((uts + pas) / 2).toFixed(2);
}

// Fungsi untuk menentukan keterangan lulus/tidak lulus
function tentukanKeterangan(rataRata) {
    const nilaiRataRata = parseFloat(rataRata);
    return nilaiRataRata >= 70 ? 'Lulus' : 'Tidak Lulus';
}

// Fungsi untuk menambah data siswa
function tambahDataSiswa() {
    const nama = namaInput.value.trim();
    const uts = parseFloat(utsInput.value);
    const pas = parseFloat(pasInput.value);

    // Validasi input
    if (!nama || isNaN(uts) || isNaN(pas)) {
        alert('Mohon isi semua data dengan benar!');
        return;
    }

    if (uts < 0 || uts > 100 || pas < 0 || pas > 100) {
        alert('Nilai harus antara 0-100!');
        return;
    }

    // Hitung rata-rata
    const rataRata = hitungRataRata(uts, pas);
    const keterangan = tentukanKeterangan(rataRata);

    // Buat object siswa
    const siswa = {
        id: Date.now(),
        nama: nama,
        uts: uts,
        pas: pas,
        rataRata: rataRata,
        keterangan: keterangan
    };

    // Tambah ke array
    dataSiswa.push(siswa);

    // Reset form
    formNilai.reset();
    namaInput.focus();

    // Update tampilan
    tampilkanData();
    updateStatistik();
}

// Fungsi untuk menampilkan data di tabel
function tampilkanData() {
    // Kosongkan tbody
    tbody.innerHTML = '';

    if (dataSiswa.length === 0) {
        tabelNilai.style.display = 'none';
        noData.style.display = 'block';
        return;
    }

    tabelNilai.style.display = 'table';
    noData.style.display = 'none';

    dataSiswa.forEach((siswa, index) => {
        const row = document.createElement('tr');
        
        const kelasKeterangan = siswa.keterangan === 'Lulus' ? 'lulus' : 'tidak-lulus';
        
        row.innerHTML = `
            <td>${index + 1}</td>
            <td>${siswa.nama}</td>
            <td>${siswa.uts}</td>
            <td>${siswa.pas}</td>
            <td class="rata-rata">${siswa.rataRata}</td>
            <td>
                <span class="keterangan ${kelasKeterangan}">
                    ${siswa.keterangan}
                </span>
            </td>
            <td>
                <button class="btn-hapus" onclick="hapusData(${siswa.id})">Hapus</button>
            </td>
        `;

        tbody.appendChild(row);
    });
}

// Fungsi untuk menghapus data
function hapusData(id) {
    if (confirm('Apakah Anda yakin ingin menghapus data ini?')) {
        dataSiswa = dataSiswa.filter(siswa => siswa.id !== id);
        tampilkanData();
        updateStatistik();
    }
}

// Fungsi untuk update statistik
function updateStatistik() {
    const total = dataSiswa.length;
    const lulus = dataSiswa.filter(siswa => siswa.keterangan === 'Lulus').length;
    const tidakLulus = total - lulus;

    // Hitung rata-rata kelas
    let rataRataKelas = 0;
    if (total > 0) {
        const totalNilai = dataSiswa.reduce((sum, siswa) => sum + parseFloat(siswa.rataRata), 0);
        rataRataKelas = (totalNilai / total).toFixed(2);
    }

    // Update elemen
    totalSiswaEl.textContent = total;
    siswaLulusEl.textContent = lulus;
    siswaTidakLulusEl.textContent = tidakLulus;
    rataRataKelasEl.textContent = rataRataKelas;
}

// Load data dari localStorage saat halaman dibuka
window.addEventListener('load', function() {
    const savedData = localStorage.getItem('dataSiswa');
    if (savedData) {
        dataSiswa = JSON.parse(savedData);
        tampilkanData();
        updateStatistik();
    }
});

// Simpan data ke localStorage setiap kali ada perubahan
function simpanKeLocalStorage() {
    localStorage.setItem('dataSiswa', JSON.stringify(dataSiswa));
}

// Override fungsi tambah dan hapus untuk menyimpan ke localStorage
const originalTambahDataSiswa = tambahDataSiswa;
tambahDataSiswa = function() {
    originalTambahDataSiswa.call(this);
    simpanKeLocalStorage();
};

const originalHapusData = hapusData;
hapusData = function(id) {
    if (confirm('Apakah Anda yakin ingin menghapus data ini?')) {
        dataSiswa = dataSiswa.filter(siswa => siswa.id !== id);
        tampilkanData();
        updateStatistik();
        simpanKeLocalStorage();
    }
};
